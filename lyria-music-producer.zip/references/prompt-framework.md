# Lyria Agent 提示词架构：JSON Schema + 编译器逻辑

本文件提供可供 Agent 自动驱动 Lyria 的结构化执行架构（JSON Schema），以及将其编译为 Lyria 理解效果最好的自然语言提示词的"专业编曲人语言编译器"逻辑。

## 一、LyriaProMusicProductionSchema（JSON Schema）

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "LyriaProMusicProductionSchema",
  "description": "用于驱动 Google DeepMind Lyria 3 Pro 进行全长、结构化、专业级音乐生成的 Agent 架构规范。",
  "type": "object",
  "properties": {
    "mode": {
      "type": "string",
      "description": "生成模式：song(流行歌曲) / score(影视游戏配乐) / bgm-loop(循环背景)。决定结构词汇与人声开关。",
      "enum": ["song", "score", "bgm-loop"],
      "example": "score"
    },
    "creation_concept": {
      "type": "object",
      "description": "1. 创作理念：定义整首歌的核心DNA、听觉场景与核心美学。",
      "properties": {
        "genre_and_style": {
          "type": "string",
          "description": "核心音乐流派与子流派",
          "example": "Cinematic Indie Pop / Ambient"
        },
        "target_tempo_bpm": { "type": "integer", "example": 115 },
        "key_signature": { "type": "string", "example": "D minor" },
        "narrative_context": {
          "type": "string",
          "description": "场景或故事背景，引导隐式声学空间",
          "example": "A person walking alone through a neon-lit empty city at midnight, feeling reflective and detached."
        }
      },
      "required": ["genre_and_style", "target_tempo_bpm", "key_signature", "narrative_context"]
    },
    "song_structure": {
      "type": "array",
      "description": "2. 歌曲结构与时间轴规划：明确全长各段落的起止时间与区块划分。",
      "items": {
        "type": "object",
        "properties": {
          "section_name": {
            "type": "string",
            "enum": ["Intro", "Verse", "Pre-Chorus", "Chorus", "Bridge", "Guitar_Solo", "Outro"],
            "example": "Verse 1"
          },
          "time_window": { "type": "string", "example": "00:20 - 00:50" },
          "emotional_intent": { "type": "string", "example": "Intimate, vulnerable, minimal." },
          "arrangement_shift": {
            "type": "string",
            "description": "该段落的编曲演变（乐器增减）",
            "example": "Strip away all drums. Keep only dry close-miced vocal and muted acoustic guitar."
          }
        },
        "required": ["section_name", "time_window", "emotional_intent", "arrangement_shift"]
      }
    },
    "instrumentation_design": {
      "type": "object",
      "description": "3. 乐器与音色设计：定义全曲核心音色库。",
      "properties": {
        "core_instruments": {
          "type": "array",
          "items": { "type": "string" },
          "example": ["warm analog synth pad", "felt piano", "wide stereo electric guitars", "punchy live-room drums"]
        },
        "sound_design_textures": {
          "type": "string",
          "description": "微观音质与物理特征",
          "example": "Slightly detuned synths, vinyl crackle background, close-miced breathy vocals."
        }
      },
      "required": ["core_instruments"]
    },
    "vocal_performance": {
      "type": "object",
      "description": "4. 人声与演唱设计（针对包含人声的模型分支）。",
      "properties": {
        "vocal_style": {
          "type": "string",
          "example": "Breathy, half-whispered female lead in verse; multi-tracked soaring harmonies in chorus."
        },
        "lyric_theme": {
          "type": "string",
          "example": "Themes of urban isolation, searching for connection, time slipping away."
        }
      }
    },
    "production_aesthetic": {
      "type": "object",
      "description": "5. 制作审美与混音级描述。",
      "properties": {
        "spatial_imaging": {
          "type": "string",
          "example": "Intimate narrow stereo in verses expanding into a massive, lush reverb-drenched wall of sound in the chorus."
        },
        "dynamic_range": {
          "type": "string",
          "example": "High dynamic contrast: quiet, whispered verses contrasted with a towering cinematic climax."
        }
      },
      "required": ["spatial_imaging", "dynamic_range"]
    }
  },
  "required": ["mode", "creation_concept", "song_structure", "instrumentation_design", "production_aesthetic"]
}
```

## 二、专业编曲人语言编译器（Compiler Logic）

**关键规则：绝不能把整段 JSON 原封不动发给 Lyria。** Lyria / Suno 接收的是自然语言 Prompt。
编译器把 JSON 字段线性化为分段标签流文本，并遵循以下映射：

- **输出语言：英文**（除非用户明确要求中文）。所有 Genre / Aesthetic / 段落描述一律用英文书写。
- `mode` → 决定结构词汇与是否出 `Vocal:` 行：`score` / `bgm-loop` 或 `instrumental` 时**整体跳过** `vocal_performance`，不输出任何 `Vocal:` 行。
- `creation_concept` → 顶层 `[Global Specs]` 块（Genre / BPM / Key / Aesthetic / Narrative）。
- `song_structure[]` 每个元素 → 一个 `[time_window] [section_name]` 段落块，内部展开 `emotional_intent` → `Emotion:`、`arrangement_shift` → `Arrangement:`、`narrative_context` 上下文按需注入 `Theme:`。段落名按 `mode` 选择：song 用 Verse/Chorus/Bridge；score 用 Establishing/Tension/Action/Climax/Resolution。
- `instrumentation_design` → 在 `Global Specs` 与对应段落的 `Arrangement:` 中引用（具象化风格须来自 `references/style-bank.md`）。
- `vocal_performance` → 仅 `song` 模式且用户要人声时，映射为各段落的 `Vocal:` 行。
- `production_aesthetic` → `Global Specs` 的 `Aesthetic:` + 各段落的 `Mixing:` 行。

### 编译输出示例

```text
[Global Specs]
Genre: Cinematic Indie Pop, 115 BPM, Key of D minor. High-fidelity 44.1kHz studio production.
Aesthetic: Intimate narrow stereo verses expanding into a massive, lush reverb-drenched wall of sound in the chorus.

[00:00 - 00:20] [Intro]
Theme: A person walking alone through a neon-lit empty city at midnight.
Arrangement: Warm analog synth pad with a faint vinyl crackle. No percussion, ambient and reflective.

[00:20 - 00:50] [Verse 1]
Emotion: Intimate, vulnerable, minimal.
Vocal: Breathy, half-whispered female lead, dry and close-miced.
Arrangement: Strip away all drums. Accompanied solely by a felt piano.

[00:50 - 01:20] [Chorus]
Emotion: Cinematic climax.
Vocal: Multi-tracked soaring harmonies.
Arrangement: The arrangement expands massively. Wide stereo electric guitars, punchy live-room drums, and a high dynamic surge.
```

## 三、简化版 JSON（仅核心三块）

若用户只需要最小可行架构，可输出仅含 `global_metadata`、`narrative_and_emotion`、`chronological_song_structure` 三块的精简 Schema（段落枚举扩展为含 `Chorus 1 / Chorus 2 / Final Climax` 等以支持能量梯度）。该变体同样需经上述编译器转为自然语言后再提交 Lyria。
