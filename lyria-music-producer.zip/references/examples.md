# 范例库（Examples · 英文交付）

本文件提供可直接参考/改编的提示词范本。**所有编译产物均为英文**（见 SKILL.md §4），因为 Suno / Lyria 对英文提示词识别最佳。
下方中文仅为说明性注释，不进入交付给模型的提示词正文。

## 一、短 Prompt vs 长 Prompt（为何后者控制力指数级上升）

- **短（弱控制）**：`"Sad cinematic piano song"` → 仅高维特征散点，易平庸随机。
- **长（强控制）**：
  > *"A cinematic ballad about a person walking alone through a city at midnight. Intro with minimal felt piano, Verse with intimate vocal, Chorus expanding with orchestral strings and drums."*
  → 情节语境 + 时间坐标，迫使长程规划器按段落差异化注入；"深夜独行城市"转化为声音景观隐式约束。

## 二、完整 3 分钟电影感独立流行（song 模式 · 含人声）

```text
[Global Specs]
Genre: Modern Cinematic Indie Pop, 115 BPM, Key of D minor, High fidelity 44.1kHz stereo studio production.
Aesthetic: Intimate narrow stereo verses expanding into a massive, lush reverb-drenched wall of sound in the chorus.

[00:00 - 00:20] [Intro]
Minimal and atmospheric. Only a warm, slightly detuned analog synth pad and soft vinyl crackle. No percussion. Establishing a melancholic, reflective mood.

[00:20 - 00:50] [Verse 1]
Intimate and sparse. Vocals are dry, close-miced, half-whispered female lead. Accompanied solely by a muted, plucking acoustic guitar and a very subtle sub-bass pulse.

[00:50 - 01:20] [Chorus]
Cinematic climax expansion. The arrangement opens up massively: driving punchy drums with a live-room aesthetic, wide stereo electric guitars, soaring multi-tracked vocal harmonies, and a weeping cello counter-melody. High emotional intensity.

[01:20 - 01:50] [Verse 2]
Rhythmic return. Retains the drums from the chorus down-mixed to a punchy groove, but strips away the heavy guitars. Vocals become slightly more urgent, conversational, with a subtle slap-back echo.

[01:50 - 02:20] [Bridge]
Tension and modulation. The rhythm stops entirely for a two-second suspension. Then a sudden shift to a higher emotional peak with soaring, reverb-drenched operatic vocal ad-libs, building up a massive snare roll.

[02:20 - 02:55] [Outro]
Gradual decay. The massive instrumentation strips away one by one over 20 seconds. Leaving only the isolated vocal humming softly, fading out with the analog synth pad from the intro.
```

## 三、武侠打斗 · 影视配乐（score 模式 · 零人声 · 古风基底）★ 具象化风格识别

> 用户大白话："武侠打斗影视配乐，战斗激烈" → 技能查 style-bank：武侠 → 古风乐器 + 中国打击乐；score 模式 → cue 结构、零人声。

```text
[Global Specs — FILM SCORE MODE]
Genre: Chinese Wuxia Cinematic Action Score, 120 BPM driving, D minor pentatonic (羽调式), 44.1kHz stereo.
Format: Instrumental score, no vocal.
Aesthetic: Ancient Chinese (古风) tonal base fused with modern orchestral impact; narrow tense string tremolo in stealth passages expanding into an ultra-wide, wall-of-sound clash of Chinese war drums and full tutti in combat.

[00:00 - 00:15] [Establishing]
Low sheng (reed pipe) and sparse guzheng plucks, faint night-breeze ambience over a bamboo forest. Static tension, danger lurking. No percussion, no vocal.

[00:15 - 00:45] [Tension / Build]
Urgent erhu tremolo and gradually denser tanggu (Chinese war drum) patterns, string section pizzicato ascending, blade-light about to strike.

[00:45 - 01:30] [Combat / Climax]
Full ensemble eruption: pipa tremolo raining like blades, massive tanggu and luo gong hits, heroic orchestral tutti stating the theme, metallic weapon Foley shimmers. High intensity, ferocious combat, no vocal.

[01:30 - 01:50] [Resolution]
Drums cut abruptly; only a lingering erhu long note and rain ambience remain. The victor stands alone, killing intent dissolving.
```

## 四、能量梯度强化写法（杜绝"复制粘贴副歌"）

### Chorus 2 必须加码（Layering & Stacking）
> `[Chorus 1]: Energetic pop-rock chorus with driving drums and rhythm guitars.`
> `[Chorus 2]: Massive expansion of Chorus 1. Add high-register backing vocal harmonies (octave up), a soaring electric guitar counter-melody in the background, and brighter overhead drum cymbals to maximize the sonic density.`

### Bridge 欲扬先抑（Drop-out & Tension）
> `[Bridge]: Dramatic tension and contrast. At 01:50, sudden total silence of drums and bass for 2 seconds (drop out). Followed by a sparse, unaccompanied emotional vocal line, slowly building tension with a rising string swell and a snare roll leading back to the final chorus.`

### Final Climax 全频段饱和（Wall of Sound）
> `[Final Chorus / Climax]: The ultimate sonic peak. Wall of sound production. Full orchestral strings, heavy driving drums, main lead vocals accompanied by soaring gospel-style background harmonies, distorted electric rhythm guitars, and passionate vocal ad-libs. Maximum dynamic range, wide stereo panning, epic and triumphant resolution.`

## 五、避免"循环 Loop 感"的三条铁律

1. **时间轴坐标锚定**：显式引入带时间锚点/段落标签的语法。
2. **减法编曲**：段落切换写明乐器进出动态（*strips away all drums*），用织体厚度变化强迫模型改变结构。
3. **显式过渡段**：Verse↔Chorus（或 Tension↔Action）间强制加入蓄力段，用 Riser / Drop-out 制造物理断层，打破循环惯性。
