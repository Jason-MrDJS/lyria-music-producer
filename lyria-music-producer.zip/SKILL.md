---
name: lyria-music-producer
description: "专业级 AI 音乐生成提示词工程技能，面向 Google DeepMind Lyria（Lyria 3 Pro / 3.5 系列）、Suno 等具有结构控制能力的大模型音乐生成系统。当用户需要为 AI 音乐模型编写、优化或结构化音乐提示词（music prompt）、希望生成具有专业编曲结构、情感弧光、混音审美与叙事张力的歌曲或影视/游戏配乐，或需要把创作理念（含具象化风格如武侠/科幻/赛博朋克）编译为分段标签流文本或 JSON 执行架构时，使用本技能。本技能模拟专业制作人的推理过程（情绪→音乐发展、概念→结构、结构→编曲演变、编曲→配器、配器→制作风格），规避形容词堆砌与11类常见误读，而非关键词拼贴生成器。默认将交付给音乐模型的提示词输出为英文（Suno/Lyria 对英文识别最佳），仅当用户明确要求中文时才用中文。关键词：Lyria、Suno、AI 音乐生成、音乐提示词工程、prompt engineering for music、编曲、混音、歌曲结构、影视配乐、制作人级 Prompt、结构化音乐生成。"
---

# Lyria Music Producer（制作人级 AI 音乐提示词工程）

## Overview

本技能**不是关键词填表器（keyword-based generator）**，而是模拟专业音乐制作人的**推理过程（reasoning process）**。
它把用户的创作意图（情绪、概念、场景）经由一套制作人式推理链，翻译成 Lyria / Suno 能精准响应的提示词。

**推理管线（Producer Reasoning Pipeline）—— 技能一切输出的脊梁：**
- **Emotion（情绪） → Musical Development（音乐发展）**：情绪不是形容词，而是动机如何生长、张力如何释放的发展弧。
- **Concept（概念/叙事） → Song Structure（歌曲/配乐结构）**：叙事决定何时起承转合。
- **Structure（结构） → Arrangement Evolution（编曲演变）**：结构决定织体何时加减。
- **Arrangement（编曲） → Instrumentation（配器）**：编曲决定用什么声源承载。
- **Instrumentation（配器） → Production Style（制作/混音风格）**：声源决定空间与动态如何塑造。

**核心纪律**：避免形容词堆砌（adjective stacking）；优先 **时间轴编排、情感弧光、段落发展、动态演进、音乐叙事**。
通过"专业编曲人语言编译器"将推理结果编译为英文分段标签流（详见 `references/reasoning-engine.md` 的 11 条反模式与正解）。

## When to Use

在以下场景触发本技能：
- 用户要求"写一段 Lyria 提示词""帮我生成一首 AI 音乐的描述""给 Lyria 写个 prompt"。
- 用户希望 AI 生成的音乐有清晰的歌曲结构（主歌/副歌/桥段/尾声）、情绪递进、而非无限循环的 Loop。
- 用户想从一段笼统的创意（"悲伤的电影感钢琴曲"）升级为制作人级别的可控指令。
- 用户需要把音乐需求结构化为 JSON Schema，供 Agent 自动驱动 Lyria 生成。
- 用户询问 AI 音乐生成的底层逻辑、Prompt 信息权重、如何控制混音/人声/动态等。

**不适用**：本技能不执行真实音频渲染（Lyria 的推理由 Google 服务端完成）。它产出的是"最优提示词"与"结构化执行架构"，而非音频文件。

## Core Mental Model（核心心智模型）

### 1. Lyria 的底层生成逻辑（一句话版）
Lyria 采用 **"分层条件潜空间扩散 + 宏观长程规划器"** 架构：
1. **宏观语义与结构蓝图层** —— 前端 LLM（Gemini 协同）将 Prompt 解构为带时间戳的段落标记（Time-stamped Section Tokens），在时间轴上划定段落边界。
2. **中观风格与和声编排层** —— 通过交叉注意力（Cross-Attention）把流派/BPM/调性/乐器条件向量（Style Embeddings）注入生成网络。
3. **微观潜空间音频解码层** —— 底层潜空间扩散模型（LDM）将高层规划转为时序音频潜变量，渲染出 48kHz 高保真立体声。

因此，**Prompt 不是"文本分类"，而是跨模态映射到控制轴的语义-音频对齐（Semantic-Audio Alignment）。**

### 2. 八维信息影响力排序（从高到低，决定 Prompt 该把笔墨花在哪）
1. **Song Structure（曲式结构 / 时间戳）** —— 最高。直接干预长程注意力窗口，强制切换解码策略与能量等级。
2. **Instrumentation（乐器 / 织体）** —— 高。决定频谱能量占用（Sub-bass 占低频、Acoustic Guitar 占中高频）。
3. **Emotional Arc（情感弧光 / 动态）** —— 较高。决定宏观动态范围与张力释放点。
4. **Scene / Narrative（场景 / 叙事语境）** —— 中偏上。通过转化为具体乐器/速度副词间接起效。
5. **Theme（主题 / 歌词概念）** —— 中。主要影响歌词与人声演绎语气。
6. **Production Aesthetic（混音审美）** —— 中偏下。空间/质感微调，需建立在乐器与结构之上。
7. **Timbre（音色细节）** —— 较低。常依附于乐器词汇，抽象音色形容词易被主干流派冲淡。
8. **Reference Artist（参考艺术家）** —— 最低。受版权/安全护栏压制，**不要写"像某天王"，改写具体声学描述**（如"1980 年代复古合成器流行，带 Gated Reverb 鼓机"）。

### 3. 三个反"AI 感"的核心心法
- **减法编曲（Subtractive Arrangement）**：段落切换时写明乐器的"进出动态"，用织体厚度变化强迫模型改变结构，打破循环惯性。
- **能量梯度规划（Energy Gradient）**：Chorus 2 必须比 Chorus 1 加码（叠加 Counter-melody / Harmonies / 更亮的镲片），绝不允许两遍副歌相同。
- **生理与物理真实感（Human Artifacts）**：在人声/乐器描述中注入微观不完美（audible breaths, vocal fry, 钢琴机械击弦声），破坏机器冰冷感。

### 4. 输出语言规则（Output Language）—— 默认英文
最终交付给 Lyria / Suno 等音乐模型的提示词，**默认使用英文**。仅当用户明确要求中文时才输出中文。
- **理由**：Suno、Lyria 等模型对英文提示词的识别与风格控制效果最佳。
- **范围**：技能内部说明（本文件）可用中文，但**编译产物（分段标签流提示词）必须是英文**。若需中文，仅作面向用户的解释性注释，不得混入交付给模型的提示词正文。

### 5. 模式识别（Mode）—— 决定结构词汇与人声开关
在 Step 1 必须判定生成模式，不同模式使用不同的结构词汇与默认人声策略（详见 `references/style-bank.md`）：
- **song（流行/歌曲）**：使用 Verse / Chorus / Bridge 流行曲式；人声按需（用户要"有唱词/演唱"才加）。
- **score（影视 / 游戏配乐）**：纯器乐、cue 驱动；结构用 `Establishing / Tension / Action / Climax / Resolution`；**默认零人声**。
- **bgm-loop（循环背景）**：短时长、可无缝循环；结构弱化、强调织体与氛围；默认零人声或极简人声。
- **判定线索**：用户说"配乐 / BGM / 纯音乐 / 影视 / 游戏 / 无人声 / instrumental / soundtrack / 背景音乐" → `score` 或 `bgm-loop`，且**绝不带人声**；说"歌 / 演唱 / 有词 / vocal" → `song`。

## Producer Reasoning Engine（制作人推理引擎 · 必读）

本技能的一切输出都必须源自"制作人推理"，**严禁关键词拼贴**。进入 Workflow 前，先在内部完成 Overview 的推理管线，并逐条核对以下纪律。

### 推理纪律（Discipline）
- **拒绝形容词堆砌**：不写 `sad, dark, beautiful, epic` 这类形容词清单；改写为音乐发展动作（动机如何从犹豫走向宣泄、织体如何由薄到厚、动态如何由呼吸到饱和）。
- **时序优先**：任何描述都必须回答"什么时候发生（time-based）"。没有时间坐标的编曲描述视为无效，必须补上时间戳或段落标签。
- **叙事优先于"大"**："电影感"= 叙事推进与留白，绝不等于"响 / 大 / 满"。

### 11 条常见误读（必须规避）
1. **情绪 ≠ 形容词**：把"情绪"当成形容词而非音乐发展。→ 情绪应转为发展弧（生长/释放/转折）。
2. **歌曲结构 ≠ 声音结构**：混淆"主副歌叙事形式"与"频段/频谱/空间分层"。二者是不同维度，分别归 Structure 与 Production。
3. **只说"有什么"不说"何时发生"**：缺时间轴。→ 强制时间坐标（见 Step 2）。
4. **参考音乐人 ≠ 复制风格**：把艺人名当风格开关（既受版权护栏压制，控制力也最低）。→ 改写为具体声学描述。
5. **音色 ≠ 乐器名称**：乐器是声源（felt piano），音色是微观物理质感（muffled / detuned / mechanical hammer noise）。二者分层描述。
6. **忽略动态曲线**：忘了能量包络随时间的起伏（静→涌→爆→落）。
7. **电影感 ≠ 大**：把"cinematic"理解成"响/宏大"，而非叙事与留白。
8. **不懂留白**：忽视 rests / 稀疏 / 减法也是编曲核心手段（"该闭嘴时闭嘴"）。
9. **混音描述 ≠ 创作描述**：混淆 production（reverb/pan/compression）与 composition（音符/结构/主题）。分别归 Production Aesthetic 与 Structure/Concept。
10. **过度相信形容词**：形容词越多越无效，堆砌反而稀释控制力。
11. **忽略音乐逻辑冲突**：同一小节既要 whisper 又要 wall of sound 却无过渡；或 acoustic 与 heavy distortion 并存而无演变；或调性/速度自相矛盾。→ 输出前做一次逻辑自检。

每条的"错误写法 → 为何错 → 正确推理 → 中英范例"见 `references/reasoning-engine.md`。

## Workflow（标准工作流）

按以下步骤把用户创意编译为最终提示词。每一步都在 `references/` 中有更细的说明。

### Step 1 — 采集创作理念与判定模式（Creation Concept + Mode）
先判定 **Mode**（见 Core Mental Model §5）：song / score / bgm-loop。再确认或推断以下全局元数据（若用户已给则直接采用）：
- **Genre & Style**（流派与子流派，如 Cinematic Indie Pop）
- **Tempo（BPM）**
- **Key Signature**（调性，如 D minor）
- **Narrative Context**（场景/故事背景，引导隐式声学空间）
- **Production Standard**（如 44.1kHz 高保真立体声、High dynamic range）

> 若用户只给了一句笼统描述（如"武侠打斗影视配乐"），先用 `references/style-bank.md` 的映射表把具象化风格可靠地解析为流派+乐器组合，再扩展为上述字段，继续后续步骤。

### Step 2 — 绘制时间轴结构蓝图（Chronological Structural Blueprint）
这是**最关键的一步**。必须为每个段落划定明确时间窗口与区块划分，使用 **时间轴坐标锚定法**：
- 引入带时间戳/段落标签的语法：`[00:00 - 00:20] [Intro]`
- 显式设计过渡段，用 Riser / Drop-out 制造物理断层。
- **段落词汇按模式切换**：
  - `song` 模式枚举：`Intro, Verse, Pre-Chorus, Chorus, Bridge, Guitar_Solo, Outro`。
  - `score` 模式枚举：`Establishing, Tension, Build, Action, Climax, Resolution`（cue 驱动，非主副歌）。
  - `bgm-loop` 模式：弱化段落边界，强调 `Loop Section` 的织体与氛围一致性。

每个段落对象需包含：`section_name`、`time_window`、`emotional_intent`、`arrangement_shift`（增减了哪些乐器/织体）。

### Step 3 — 定义配器与音色设计（Instrumentation & Sound Design）
- 列出 **core_instruments**（核心音色库，直接映射到 Timbre Space）。**具象化风格必须从 `references/style-bank.md` 取对应乐器组合**（如武侠→guzheng/dizi/erhu/pipa/Chinese percussion），不要默认套西方流行乐器。
- 写明 **sound_design_textures**（微观音质，如 slightly detuned synths、vinyl crackle、close-miced breathy vocals）。
- 规定 **Instrument Evolution**：同一乐器在不同段落的声学形态演变（如 Verse 中闷声毡音钢琴 → Chorus 中明亮宽立体声三角钢琴）。

### Step 4 — 定义人声与演唱（Vocal Performance，仅 song 模式且用户要人声时）
- **模式约束**：若 Mode 为 `score` 或 `bgm-loop`，或用户声明"无人声 / 纯音乐 / instrumental"，**整体跳过本步**，编译时不输出 `Vocal:` 行。
- **vocal_style**：唱法/音色/情绪传达（breathy half-whispered → multi-tracked soaring harmonies）。
- **lyric_theme**：歌词主题意象。
- 注入 **微观动态**：近距离拾音、未加修饰、乐句开头清晰呼吸声与气泡音、副歌胸腔共鸣呐喊带轻微破音。

### Step 5 — 定义制作与混音审美（Production / Mixing Aesthetic）
用 **声学工程词汇（Acoustic Engineering Lexicon）** 直接操控潜空间能量分布，覆盖六大核心参数：
- **Spatial Imaging**（声场/纵深）：Verse 准单声道局促感 → Chorus 超宽 3D 沉浸式声场 + 板式混响尾音。
- **Dynamic Range**（动态范围）：Verse 未压缩呼吸感 → Chorus 高饱和 wall-of-sound 压缩母带。
- **Timbre & Tone**（音色）：暗暖模拟 tone、滚降刺耳高频、低频泥泞切除。
- **Vocal Processing**：close-miced + tape saturation + slap-back delay + double-tracked harmonies。
- **Emotional Proximity**（情绪距离）：Verse "in-your-ear" 近距离 → Chorus 体育场级远距离。
- **Spectral Density**（编曲密度）：Verse 稀疏留白 → Chorus 高频谱密度多层交织。

### Step 6 — 编译为最终 Lyria / Suno 提示词（Producer Language Compiler）
**不要把 JSON 原样发给模型。** 将结构化数据编译为分段标签流自然语言。
**输出语言：英文（除非用户明确要求中文）**——所有 Genre / Aesthetic / 段落描述一律用英文书写。
**按目标模型选择格式**：
- **目标 Lyria（默认）**：用 `[Global Specs]` + `[时间][段落]` 标签流（见 `references/examples.md`、`references/prompt-framework.md`）。
- **目标 Suno 或用户要求 bracket 标签**：改用 `references/suno-tag-system.md` 的 **`[track]` 容器 + 段落标签 + 歌词/描述置于标签下** 的语法，并遵守其 v4.0+ 解析规则（冒号安全嵌入指令、指令不放在标签外、防循环用 `[verse A]/[verse B]`、长作品加 `[sequence:]`、避开已废弃标签与 `bpm/key/language` 别名、商标护栏）。

Lyria 格式示例（英文）：
```
[Global Specs]
Genre: ... BPM: ... Key: ...
Aesthetic: ...

[00:00 - 00:20] [Intro]
Theme / Emotion / Arrangement / Vocal / Mixing ...

[00:20 - 00:50] [Verse 1]
...
```
始终按 `references/examples.md` 的英文范本输出，确保段落演进、动态包络、空间叙事完整。

**输出前自检**：按 `references/reasoning-engine.md` 的 11 条清单过一遍——重点排除"形容词堆砌""只说有什么不说何时发生""音色与乐器名混淆""电影感=大""音乐逻辑冲突"等误读，确认情绪已转为发展弧、每个元素都绑定了时间/段落。

### Step 7 —（可选）输出结构化 JSON Schema
若用户需要供 Agent 自动驱动 Lyria，按 `references/prompt-framework.md` 中的 JSON Schema 输出结构化执行架构（含 `creation_concept`、`song_structure`、`instrumentation_design`、`vocal_performance`、`production_aesthetic`）。

## Producer Lexicon（高频有效"动作词"，直接写入 Prompt）

> 本词典提供的是**编曲动作词（动词/动作）**，而非形容词。与推理纪律一致：用动作描述"音乐如何发展"，避免形容词堆砌。
- **结构/动态**：minimal, sparse, strip away, layer, expand, drop out, build up, counter-melody, wall of sound, crescendo, fade out, drop the drums, double the rhythmic density。
- **混音空间**：narrow mono-ish, ultra-wide 3D immersive soundstage, plate reverb tail, dry room, close-miced, in-your-ear, stadium-sized distance。
- **生理真实**：audible breaths, vocal fry, mechanical hammer noises, tape saturation, raw emotion crack。
- **能量对比**：intimate vs cinematic climax, low spectral density vs high sonic density, quiet whispered vs towering peak。

## References
详细方法、JSON Schema、完整编译逻辑与范本见：
- `references/reasoning-engine.md` —— **制作人推理引擎**：11 条反模式（情绪≠形容词、结构≠声音结构、电影感≠大、音色≠乐器名…）的"错误写法→为何错→正确推理→范例" + 输出前自检清单。
- `references/architecture.md` —— Lyria 底层层级生成逻辑、八维权重、结构控制难点与对策。
- `references/prompt-framework.md` —— 完整 JSON Schema 定义（含 mode 字段）+ "专业编曲人语言编译器"逻辑与编译示例。
- `references/style-bank.md` —— **场景/风格 → 流派 + 乐器 映射词库**（武侠/古风/科幻/赛博朋克/史诗/恐怖/治愈等）+ 模式判定线索，是具象化风格识别的核心数据源。
- `references/producer-playbook.md` —— 制作人六大维度工程学（结构/情感/编曲/乐器/人声/混音）+ 混音师视角六参数控制法。
- `references/examples.md` —— 英文范本：短 vs 长 Prompt 对比、3 分钟电影感流行歌、武侠打斗影视配乐（score 模式 / 零人声）、Chorus2/Bridge/Climax 强化写法。
- `references/suno-tag-system.md` —— **Suno 括号标签控制系统**（源自《AI 音乐提示词终极指南》规范）：`[track]` 容器、管道符局部覆盖、按功能分类的元标签词汇、器乐 vs 人声规则、v4.0+ 解析规则（冒号语法/防循环/`[sequence:]`）、已废弃标签与商标护栏。目标为 Suno 或用户要求 bracket 标签时使用。
