# lyria-music-producer

**制作人级 AI 音乐提示词工程技能 · 面向 Lyria / Suno**

一个给 AI 音乐模型（Google DeepMind Lyria、Suno）写提示词的技能。它**不是关键词填表器**，而是模拟专业音乐制作人的推理过程，把你的创作想法（情绪、场景、风格）编译成模型能精准响应的结构化提示词。

---

## 能做什么

- 把大白话（"武侠打斗配乐""深夜城市孤独感"）变成可控的**英文**音乐提示词
- 自动识别具象化风格（武侠 / 科幻 / 赛博朋克 / 史诗 / 恐怖 / 治愈…）并映射成对应乐器与流派
- 区分三种模式：
  - **song** 流行歌曲（Verse / Chorus / Bridge）
  - **score** 影视 / 游戏配乐（cue 结构，**默认零人声**）
  - **bgm-loop** 循环背景（弱化段落、强调织体一致）
- 用**时间轴编排 + 动态演进 + 留白**，杜绝"无限循环 Loop 感"
- 支持 Lyria 的 `[时间][段落]` 标签流 与 Suno 的 `[track]` 元标签两种格式
- 内置 JSON Schema + 编译器，可让 Agent 自动驱动 Lyria

---

## 核心纪律（避免"AI 感"）

- **情绪 ≠ 形容词**：要写成"发展弧"（动机如何生长、张力如何释放）
- **时序优先**：每个元素都要绑定时间 / 段落
- **参考艺人 ≠ 风格**：改写成具体声学描述，别写"像某天王"
- **电影感 ≠ 大**：留白与叙事张力，而不是推满乐器

---

## 怎么用

在 WorkBuddy 中直接说：

> "用 lyria 技能帮我写一段武侠打斗配乐的提示词"

或描述你的音乐想法即可触发。

---

## 目录结构

| 文件 | 内容 |
|---|---|
| `SKILL.md` | 主流程、核心心智模型、制作人推理引擎 |
| `references/architecture.md` | Lyria 底层生成逻辑、八维权重 |
| `references/prompt-framework.md` | JSON Schema + 提示词编译器 |
| `references/reasoning-engine.md` | 11 条反模式与输出前自检清单 |
| `references/style-bank.md` | 风格 → 流派 + 乐器 映射词库 |
| `references/producer-playbook.md` | 制作人六维度 + 混音师六参数 |
| `references/suno-tag-system.md` | Suno 括号标签控制系统 |
| `references/examples.md` | 英文交付范本 |

---

## License

MIT
